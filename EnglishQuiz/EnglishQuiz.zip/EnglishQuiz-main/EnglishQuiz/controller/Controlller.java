package controller;

public interface Controlller {
    abstract void abrirView();
}
